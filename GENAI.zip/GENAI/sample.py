import pandas as pd
from sklearn.linear_model import LogisticRegression


data={
    "hours":[2,4,6,8,10,12],
    "result":[0,0,0,1,1,1]

}
df=pd.DataFrame(data)
model=LogisticRegression()
x=df[["hours"]]
y=df["result"]
c=model.fit(x,y)
print("Model trained ")
